<template>
  <div>卡片页面</div>
</template>

<script>
export default {
  name: 'Index'
}
</script>

<style scoped>

</style>
